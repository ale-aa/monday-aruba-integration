const { Resend } = require('resend');

class EmailService {
  constructor() {
    const apiKey = process.env.RESEND_API_KEY;

    if (!apiKey || !apiKey.trim()) {
      console.warn('[EmailService] RESEND_API_KEY not configured — emails will be skipped');
      this.resend = null;
      return;
    }

    this.resend = new Resend(apiKey.trim());
  }

  async sendEmail({ to, subject, html }) {
    if (!this.resend) {
      console.log('[EmailService] Email not sent because RESEND_API_KEY is missing');
      return;
    }

    return this.resend.emails.send({
      from: 'noreply@example.com',
      to,
      subject,
      html,
    });
  }
}

module.exports = EmailService;
